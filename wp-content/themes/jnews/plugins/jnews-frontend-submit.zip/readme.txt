Change Log :

== 7.0.4 ==
- [IMPROVEMENT] Replace .bind() with .on()

== 7.0.3 ==
- [BUG] Remove session to avoid loopback issue on Site Health
- [IMPROVEMENT] Replace .ready() with .on()

== 7.0.2 ==
- [IMPROVEMENT] Add remaining quota if WooCommerce mode used

== 7.0.1 ==
- [BUG] Fix login popup in header button

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.1 ==
- [IMPROVEMENT] Add filter for wp_editor

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.1 ==
- [IMPROVEMENT] Use hooks to override page template

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.2 ==
- [BUG] Fix wp media issue

== 4.0.1 ==
- [BUG] Fix metabox issue with WooCommerce

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.3 ==
- [IMPROVEMENT] Improve customizer speed performance

== 2.0.2 ==
- [BUG] Fix undefined label index issue on account page

== 2.0.1 ==
- [IMPROVEMENT] Use modified date instead creation date on post meta date

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.0 ==
- First Release
